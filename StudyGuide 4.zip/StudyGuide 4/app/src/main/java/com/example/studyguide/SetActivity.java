package com.example.studyguide;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class SetActivity extends AppCompatActivity {

    private EditText Title;
    private EditText Question;
    private EditText Answer;
    private Button Next;
    private Button Finish;
    String InputTitle;
    String InputQuestion;
    String InputAnswer;
    private FirebaseAuth mAuth;
    private String userID;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set);
        SetUP();
        mAuth = FirebaseAuth.getInstance();

        Next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Collect();
                SendData();
                Question.setText(null);
                Answer.setText(null);
            }
        });

        Finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Collect();
                SendData();
                finish();
                startActivity(new Intent(SetActivity.this, HomePageActivity.class));
            }
        });
    }

    public void Collect() {
        InputTitle = Title.getText().toString().trim().toUpperCase();
        InputQuestion = Question.getText().toString();
        InputAnswer = Answer.getText().toString();
    }

    private void SetUP() {
        Title = findViewById(R.id.TitleText);
        Question = findViewById(R.id.QuestionText);
        Answer = findViewById(R.id.AnswerText);
        Next = findViewById(R.id.buttonNext);
        Finish = findViewById(R.id.buttonDone);
    }

    public String CurrentUserID() {
        FirebaseUser user = mAuth.getCurrentUser();
        return userID = user.getUid();
    }

    private void SendData() {
        FirebaseDatabase Database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = Database.getReference();
        Topics topic = new Topics(InputQuestion, InputAnswer);
        myRef.child(CurrentUserID()).child(InputTitle).push().setValue(topic);
    }
}

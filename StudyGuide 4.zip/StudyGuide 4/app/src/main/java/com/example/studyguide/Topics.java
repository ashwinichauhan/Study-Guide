package com.example.studyguide;
import com.google.firebase.database.IgnoreExtraProperties;
import com.google.firebase.firestore.*;

@IgnoreExtraProperties
public class Topics {


    private String UserQuestion;
    private String UserAnswer;
    private String UserTitle;

    public Topics(String userQuestion, String userAnswer) {
        UserQuestion = userQuestion;
        UserAnswer = userAnswer;
    }

    public  Topics() {

    }



    public String getUserQuestion() {
        return UserQuestion;
    }

    public void setUserQuestion(String userQuestion) {
        UserQuestion = userQuestion;
    }

    public String getUserAnswer() {
        return UserAnswer;
    }

    public void setUserAnswer(String userAnswer) {
        UserAnswer = userAnswer;
    }

    public String getUserTitle() {
        return UserTitle;
    }

    public void setUserTitle(String userTitle) {
        UserTitle = userTitle;
    }

}

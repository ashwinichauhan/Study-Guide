package com.example.studyguide;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class SignUpActivity extends AppCompatActivity {

    private EditText UserPassword;
    private EditText UserEmail;
    private Button SignUp;
    private TextView Registered;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        setupUIViews();

        mAuth = FirebaseAuth.getInstance();

        SignUp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validate()) {
                    // Upload to the database
                    String user_email = UserEmail.getText().toString().trim();
                    String user_password = UserPassword.getText().toString().trim();

                    mAuth.createUserWithEmailAndPassword(user_email, user_password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                EmailSender();
                            }
                            else {
                                // If sign in fails, display a message to the user.
                                Toast.makeText(SignUpActivity.this, "Authentication failed.", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }
            }
        });

        Registered.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SignUpActivity.this, MainActivity.class));
            }
        });
    }

    private void setupUIViews() {
        UserPassword = findViewById(R.id.EditNewPassword);
        UserEmail = findViewById(R.id.EditNewEmail);
        SignUp = findViewById(R.id.buttonSignUp);
        Registered = findViewById(R.id.Status);
    }

    private Boolean validate() {
        Boolean result = false;
        String password = UserPassword.getText().toString();
        String email = UserEmail.getText().toString();

        if(email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Missing Information", Toast.LENGTH_SHORT).show();
        }
        else {
            result = true;
        }
        return result;
    }

    private void EmailSender() {
        FirebaseUser BaseUser = mAuth.getCurrentUser();
        if(BaseUser != null) {
            BaseUser.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                @Override
                public void onComplete(@NonNull Task<Void> task) {
                    if(task.isSuccessful()) {
                        Toast.makeText(SignUpActivity.this, "Successfully Registered, Verification Mail Sent!!!", Toast.LENGTH_SHORT).show();
                        mAuth.signOut();
                        finish();
                        startActivity(new Intent(SignUpActivity.this, MainActivity.class));
                    }
                    else {
                        Toast.makeText(SignUpActivity.this, "Verification Mail hasn't been sent!", Toast.LENGTH_SHORT).show();

                    }
                }
            });
        }
    }
}

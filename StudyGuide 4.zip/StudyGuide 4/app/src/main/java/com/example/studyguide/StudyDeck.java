package com.example.studyguide;

public class StudyDeck {
    private String SetQuestion;
    private String SetAnswer;

    public StudyDeck() {
    }

    public StudyDeck(String setQuestion, String setAnswer) {
        SetQuestion = setQuestion;
        SetAnswer = setAnswer;
    }

    public String getSetQuestion() {
        return SetQuestion;
    }

    public void setSetQuestion(String setQuestion) {
        SetQuestion = setQuestion;
    }

    public String getSetAnswer() {
        return SetAnswer;
    }

    public void setSetAnswer(String setAnswer) {
        SetAnswer = setAnswer;
    }


}
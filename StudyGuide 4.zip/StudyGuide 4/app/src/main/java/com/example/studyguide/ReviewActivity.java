package com.example.studyguide;

import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.view.View.OnClickListener;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.FirebaseAuth;

import com.google.firebase.database.ValueEventListener;

import java.util.List;
import java.util.ArrayList;


public class ReviewActivity extends AppCompatActivity {

    private EditText title;
    private FirebaseAuth mAuth = FirebaseAuth.getInstance();
    private ListView questionDisplay;
    private Button review;
    private FirebaseUser user;
    private String userID ;
    private FirebaseAuth.AuthStateListener mAuthListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_review);
        init();
        user = mAuth.getCurrentUser();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                FirebaseUser user = firebaseAuth.getCurrentUser();
            }
        };
        userID = user.getUid();
        //TODO on click of the button, read the title text and call the showdata with the text
        //TODO create a new custom Adapter class for the ListView in order to display the data


        review.setOnClickListener( new OnClickListener(){

            @Override
            public void onClick(View v){



            }

        });

        FirebaseDatabase Database = FirebaseDatabase.getInstance();
        DatabaseReference myRef = Database.getReference();

        myRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                showData(dataSnapshot);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });

    }

    private void showData(DataSnapshot dataSnapshot) {
        List<String> array = new ArrayList<>();
        List<Topics> topics = new ArrayList<>();

            topics.clear();
            Topics topic = new Topics();
            List<String> keys = new ArrayList<>();
        for(DataSnapshot ds: dataSnapshot.getChildren()) {

            Log.d("Child*** ", ds.child("DD").getValue()+"");
            keys.add(ds.getKey());
            String text="";
            Object obj = ds.child(title.getText().toString()).getValue();
            if(obj != null ){
                text= obj.toString();

                String[] quesAns = text.split("\\{");
                for(int i=0; i < quesAns.length; i++) {

                    if(quesAns[i].contains("userAnswer")) {
                        String temp = quesAns[i].substring(0, quesAns[i].indexOf("}"));

                        String[] temp1 = temp.split(",");
                        String question = temp1[1].substring(temp1[1].indexOf("=")+1, temp1[1].length());
                        String answer = temp1[0].substring(temp1[0].indexOf("=")+1, temp1[0].length());
                        System.out.println(question+" "+answer);
                        //TODO the question and answer should be set in some textview and displayed on the ui

                    }
                    array.add(quesAns[i]);
                }
            }
        }
    }

    private void init() {
        title = findViewById(R.id.TitleText);
        questionDisplay = findViewById(R.id.listView);
        review = findViewById(R.id.buttonGo);

    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }


    @Override
    public void onStop() {
        super.onStop();
        if(mAuthListener != null) {
            mAuth.removeAuthStateListener(mAuthListener);
        }
    }

}

package com.example.studyguide;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {

    // Login Variables
    private EditText Email;
    private EditText Password;
    private TextView Info;
    private Button Login;
    private int attempts = 5;
    private Button Register;
    private FirebaseAuth mAuth;
    private ProgressDialog progressDialog;
    private TextView Forgot;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Assigning the variables to their respective component
        Email = (EditText)findViewById(R.id.editUseremail);
        Password = (EditText)findViewById(R.id.editPassword);
        Info = (TextView)findViewById(R.id.InfoAttempt);
        Login = (Button)findViewById(R.id.ButtonLogin);
        Register = (Button)findViewById(R.id.buttonSignUp);
        Forgot = (TextView)findViewById(R.id.ForgotPassword);

        Info.setText("No. of attempts remaining: 5");

        mAuth = FirebaseAuth.getInstance();
        progressDialog = new ProgressDialog(this);

        FirebaseUser user = mAuth.getCurrentUser();

        if(user != null) {
            finish();
            startActivity(new Intent(MainActivity.this, HomePageActivity.class));
        }

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(Input()) {
                    validate(Email.getText().toString(), Password.getText().toString());
                }
                else {
                    Toast.makeText(MainActivity.this, "Missing Information", Toast.LENGTH_SHORT).show();
                }
            }
        });

        Register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SignUpActivity.class));
            }
        });

        Forgot.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ResetActivity.class));
            }
        });
    }

    private void validate(String userEmail, String userPassword) {
        progressDialog.setMessage("Verifying...");
        progressDialog.show();

        mAuth.signInWithEmailAndPassword(userEmail, userPassword).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()) {
                    progressDialog.dismiss();
                    EmailVerification();
                }
                else {
                    progressDialog.dismiss();
                    Toast.makeText(MainActivity.this, "Login Failed", Toast.LENGTH_SHORT).show();
                    attempts--;
                    Info.setText("No. of attempts remaining: " + attempts);
                    if(attempts == 0) {
                        Login.setEnabled(false);
                    }
                }
            }
        });
    }

    private Boolean Input() {
        Boolean result = false;
        String inputpassword = Password.getText().toString();
        String inputemail = Email.getText().toString();

        if(inputemail.isEmpty() || inputpassword.isEmpty()) {
            Toast.makeText(this, "Missing Information", Toast.LENGTH_SHORT).show();
        }
        else {
            result = true;
        }
        return result;
    }

    private void EmailVerification() {
        FirebaseUser BaseUser = FirebaseAuth.getInstance().getCurrentUser();
        Boolean emailflag = BaseUser.isEmailVerified();

        if(emailflag) {
            finish();
            startActivity(new Intent(MainActivity.this, HomePageActivity.class));
        }
        else {
            Toast.makeText(this, "Verify your email", Toast.LENGTH_SHORT).show();
            mAuth.signOut();
        }
    }
}
